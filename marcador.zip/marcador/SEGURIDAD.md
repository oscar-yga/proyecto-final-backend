# SEGURIDAD.md — Recomendaciones de IA para la API de Marcador en Vivo

## Herramienta usada
Claude (Anthropic), en la aplicación de chat claude.ai.

## Prompt que usé
> Estoy construyendo una API REST con Django REST Framework y JWT (djangorestframework-simplejwt)
> para un sistema de marcadores deportivos. Tiene tres roles (anónimo, planillero y administrador),
> un front externo en HTML/JS que corre en http://127.0.0.1:5500 y consume la API con
> `Authorization: Bearer <token>`. Dame recomendaciones de seguridad concretas para esta API
> (configuración de settings.py, autenticación, autorización, CORS, límites de peticiones,
> manejo de secretos y tokens) y dime para cada una cómo aplicarla en Django/DRF.

## Recomendaciones recibidas y dónde las apliqué

| # | Recomendación de la IA | Aplicada | Dónde |
|---|------------------------|----------|-------|
| 1 | No dejar `SECRET_KEY` ni `DEBUG` fijos en el código: leerlos desde variables de entorno, con valor por defecto solo para desarrollo. | Sí | `marcador/settings.py`: `SECRET_KEY = os.environ.get("DJANGO_SECRET_KEY", ...)` y `DEBUG` desde `DJANGO_DEBUG` (por defecto `True` solo para desarrollo). `ALLOWED_HOSTS` también sale de `DJANGO_ALLOWED_HOSTS`. |
| 2 | Restringir CORS al origen del front y nunca usar `CORS_ALLOW_ALL_ORIGINS`. | Sí | `settings.py`: `CORS_ALLOWED_ORIGINS` con `http://127.0.0.1:5500` y `http://localhost:5500` (configurable con `CORS_ALLOWED_ORIGINS`); `CORS_ALLOW_CREDENTIALS = False` porque el front usa Bearer, no cookies. `corsheaders.middleware.CorsMiddleware` va primero en `MIDDLEWARE`. |
| 3 | Limitar la cantidad de peticiones (throttling) para frenar abuso y fuerza bruta. | Sí | `settings.py`, `REST_FRAMEWORK`: `AnonRateThrottle` (300/min), `UserRateThrottle` (600/min) y un alcance propio `login` (100/min) en `/api/token/` y `/api/token/refresh/` (`torneo/api_views.py`, `ScopedRateThrottle`). Los valores son holgados porque el front se refresca cada 15 s. |
| 4 | Access token de vida corta (máximo 60 min) y refresh token con vencimiento. | Sí | `settings.py`, `SIMPLE_JWT`: access de 30 min (el código impide superar 60 min aunque se cambie por entorno) y refresh de 1 día. |
| 5 | Usar solo autenticación JWT en la API (sin sesión/cookies) para que las peticiones sin token respondan 401 y no haya CSRF en la API. | Sí | `settings.py`: `DEFAULT_AUTHENTICATION_CLASSES` solo con `JWTAuthentication`. |
| 6 | Denegar por defecto y autorizar por rol en el servidor (no confiar en que el front oculte botones). | Sí | `torneo/permissions.py`: `RolPermission` (`BasePermission`) como permiso por defecto. Anónimo solo GET; planillero solo PATCH de `goles_local`, `goles_visita` y `estado`; administrador todo. `torneo/roles.py` calcula el rol desde los grupos. |
| 7 | Validar la entrada en el servidor, incluidas las reglas de negocio. | Sí | `torneo/serializers.py` (`PartidoSerializer.validate`: un equipo no juega contra sí mismo y local/visita deben ser de la liga del partido) y `Partido.clean()` para el sitio HTML. Datos inválidos responden 400. |
| 8 | Devolver solo JSON y los campos necesarios (sin exponer datos de usuarios). | Sí | `DEFAULT_RENDERER_CLASSES` solo `JSONRenderer`; los serializers listan los campos explícitamente y `/api/me/` entrega solo `id`, `username` y `rol`. |
| 9 | Cabeceras y cookies seguras: `X_FRAME_OPTIONS`, `nosniff`, cookies `Secure` cuando no hay `DEBUG`. | Sí | `settings.py`: `X_FRAME_OPTIONS = "DENY"`, `SECURE_CONTENT_TYPE_NOSNIFF = True` y, si `DEBUG` es falso, `SESSION_COOKIE_SECURE` y `CSRF_COOKIE_SECURE`. |
| 10 | Proteger los formularios del sitio HTML con CSRF. | Sí | Todos los formularios POST llevan `{% csrf_token %}`, incluido el cierre de sesión de la navbar. |
| 11 | Validadores de contraseña de Django. | Sí | `settings.py`: `AUTH_PASSWORD_VALIDATORS`. |
| 12 | Forzar HTTPS (`SECURE_SSL_REDIRECT`, HSTS) en producción. | No | Se trabaja en `http://127.0.0.1`, donde HTTPS no está disponible. Se activaría al desplegar detrás de un servidor con certificado. |
| 13 | Lista negra de refresh tokens (`rest_framework_simplejwt.token_blacklist`) y rotación. | No | Queda fuera del alcance de la evaluación; el riesgo se reduce con el refresh de 1 día y el almacenamiento en `sessionStorage` del front. |
| 14 | Guardar los secretos en un archivo `.env` fuera del repositorio. | Parcial | Se leen de variables de entorno; no se entrega un `.env` para no incluir secretos en el zip. |

## Cómo usar las variables de entorno
```bash
export DJANGO_SECRET_KEY="una-clave-larga-y-aleatoria"
export DJANGO_DEBUG=False
export DJANGO_ALLOWED_HOSTS="mi-dominio.cl"
export CORS_ALLOWED_ORIGINS="https://mi-front.cl"
export JWT_ACCESS_MINUTES=30
```
Sin variables, el proyecto corre igual en modo desarrollo.
