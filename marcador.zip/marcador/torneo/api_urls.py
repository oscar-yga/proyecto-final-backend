from django.urls import include, path
from rest_framework.routers import DefaultRouter

from .api_views import (
    EquipoViewSet,
    JugadorViewSet,
    LigaViewSet,
    LoginView,
    MeView,
    PartidoViewSet,
    RefreshView,
)

router = DefaultRouter()
router.register("ligas", LigaViewSet, basename="ligas")
router.register("equipos", EquipoViewSet, basename="equipos")
router.register("jugadores", JugadorViewSet, basename="jugadores")
router.register("partidos", PartidoViewSet, basename="partidos")

urlpatterns = [
    path("token/", LoginView.as_view(), name="token_obtain_pair"),
    path("token/refresh/", RefreshView.as_view(), name="token_refresh"),
    path("me/", MeView.as_view(), name="me"),
    path("", include(router.urls)),
]
