"""Roles del sistema, basados en grupos de Django.

- Público (sin sesión): solo mira.
- "Planillero": además actualiza goles_local, goles_visita y estado.
- "Administrador" (o superusuario): CRUD completo.
"""
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin

GRUPO_ADMINISTRADOR = "Administrador"
GRUPO_PLANILLERO = "Planillero"


def rol_de(user):
    """Devuelve 'administrador', 'planillero' o 'lector'."""
    if not user or not user.is_authenticated:
        return "lector"
    if user.is_superuser:
        return "administrador"
    grupos = set(user.groups.values_list("name", flat=True))
    if GRUPO_ADMINISTRADOR in grupos:
        return "administrador"
    if GRUPO_PLANILLERO in grupos:
        return "planillero"
    return "lector"


def es_administrador(user):
    return rol_de(user) == "administrador"


def es_planillero(user):
    """True para planillero y también para administrador (puede planillar)."""
    return rol_de(user) in ("planillero", "administrador")


class AdministradorRequiredMixin(LoginRequiredMixin, UserPassesTestMixin):
    """Sin sesión -> redirige al login. Con sesión sin rol -> 403."""

    def test_func(self):
        return es_administrador(self.request.user)


class PlanilleroRequiredMixin(LoginRequiredMixin, UserPassesTestMixin):
    def test_func(self):
        return es_planillero(self.request.user)
