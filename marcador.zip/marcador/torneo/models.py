from django.core.exceptions import ValidationError
from django.db import models
from django.urls import reverse


class Liga(models.Model):
    nombre = models.CharField(max_length=100)
    pais = models.CharField(max_length=60)
    temporada = models.CharField(max_length=20)

    class Meta:
        ordering = ["nombre", "temporada"]

    def __str__(self):
        return f"{self.nombre} ({self.temporada})"

    def get_absolute_url(self):
        return reverse("liga_detail", args=[self.pk])


class Equipo(models.Model):
    nombre = models.CharField(max_length=100)
    ciudad = models.CharField(max_length=80)
    liga = models.ForeignKey(Liga, on_delete=models.CASCADE, related_name="equipos")

    class Meta:
        ordering = ["nombre"]

    def __str__(self):
        return self.nombre

    def get_absolute_url(self):
        return reverse("equipo_detail", args=[self.pk])


class Jugador(models.Model):
    POSICIONES = [
        ("POR", "Portero"),
        ("DEF", "Defensa"),
        ("MED", "Mediocampista"),
        ("DEL", "Delantero"),
    ]

    nombre = models.CharField(max_length=100)
    numero = models.PositiveSmallIntegerField()
    posicion = models.CharField(max_length=3, choices=POSICIONES)
    equipo = models.ForeignKey(Equipo, on_delete=models.CASCADE, related_name="jugadores")

    class Meta:
        ordering = ["equipo", "numero"]

    def __str__(self):
        return f"{self.nombre} (#{self.numero})"

    def get_absolute_url(self):
        return reverse("jugador_list")


class Partido(models.Model):
    PROGRAMADO = "programado"
    EN_JUEGO = "en_juego"
    FINALIZADO = "finalizado"
    ESTADOS = [
        ("programado", "Programado"),
        ("en_juego", "En juego"),
        ("finalizado", "Finalizado"),
    ]

    liga = models.ForeignKey(Liga, on_delete=models.CASCADE, related_name="partidos")
    local = models.ForeignKey(Equipo, on_delete=models.CASCADE, related_name="partidos_local")
    visita = models.ForeignKey(Equipo, on_delete=models.CASCADE, related_name="partidos_visita")
    fecha = models.DateTimeField()
    estadio = models.CharField(max_length=100, blank=True)
    goles_local = models.PositiveSmallIntegerField(default=0)
    goles_visita = models.PositiveSmallIntegerField(default=0)
    estado = models.CharField(max_length=12, choices=ESTADOS, default="programado")

    class Meta:
        ordering = ["fecha", "id"]

    def __str__(self):
        if not (self.local_id and self.visita_id):
            return "Partido sin equipos"
        dia = f"{self.fecha:%d/%m/%Y}" if self.fecha else "sin fecha"
        return f"{self.local} vs {self.visita} ({dia})"

    def get_absolute_url(self):
        return reverse("partido_detail", args=[self.pk])

    def clean(self):
        """Reglas de negocio: un equipo no juega contra sí mismo y ambos
        equipos deben pertenecer a la liga del partido."""
        super().clean()
        errores = []
        if self.local_id and self.visita_id and self.local_id == self.visita_id:
            errores.append("Un equipo no puede jugar contra sí mismo.")
        if self.liga_id:
            if self.local_id and self.local.liga_id != self.liga_id:
                errores.append("El equipo local no pertenece a la liga del partido.")
            if self.visita_id and self.visita.liga_id != self.liga_id:
                errores.append("El equipo visita no pertenece a la liga del partido.")
        if errores:
            raise ValidationError(errores)
