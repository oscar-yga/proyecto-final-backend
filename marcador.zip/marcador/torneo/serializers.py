from rest_framework import serializers

from .models import Equipo, Jugador, Liga, Partido


class LigaSerializer(serializers.ModelSerializer):
    class Meta:
        model = Liga
        fields = ["id", "nombre", "pais", "temporada"]


class EquipoSerializer(serializers.ModelSerializer):
    liga_nombre = serializers.CharField(source="liga.nombre", read_only=True)

    class Meta:
        model = Equipo
        fields = ["id", "nombre", "ciudad", "liga", "liga_nombre"]


class JugadorSerializer(serializers.ModelSerializer):
    equipo_nombre = serializers.CharField(source="equipo.nombre", read_only=True)

    class Meta:
        model = Jugador
        fields = ["id", "nombre", "numero", "posicion", "equipo", "equipo_nombre"]


class PartidoSerializer(serializers.ModelSerializer):
    liga_nombre = serializers.CharField(source="liga.nombre", read_only=True)
    local_nombre = serializers.CharField(source="local.nombre", read_only=True)
    visita_nombre = serializers.CharField(source="visita.nombre", read_only=True)

    class Meta:
        model = Partido
        fields = [
            "id", "liga", "liga_nombre",
            "local", "local_nombre",
            "visita", "visita_nombre",
            "fecha", "estadio",
            "goles_local", "goles_visita", "estado",
        ]

    def validate(self, attrs):
        """Mismas reglas de negocio que Partido.clean(), también en PATCH
        (usa el valor existente cuando el campo no viene en la petición)."""
        liga = attrs.get("liga", getattr(self.instance, "liga", None))
        local = attrs.get("local", getattr(self.instance, "local", None))
        visita = attrs.get("visita", getattr(self.instance, "visita", None))

        errores = {}
        if local and visita and local.pk == visita.pk:
            errores["visita"] = "Un equipo no puede jugar contra sí mismo."
        if liga and local and local.liga_id != liga.pk:
            errores["local"] = "El equipo local no pertenece a la liga del partido."
        if liga and visita and visita.liga_id != liga.pk:
            errores["visita"] = "El equipo visita no pertenece a la liga del partido."
        if errores:
            raise serializers.ValidationError(errores)
        return attrs
