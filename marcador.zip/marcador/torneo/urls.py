from django.urls import path

from . import views

urlpatterns = [
    path("", views.InicioView.as_view(), name="inicio"),

    path("partidos/", views.PartidoListView.as_view(), name="partido_list"),
    path("partidos/nuevo/", views.PartidoCreateView.as_view(), name="partido_create"),
    path("partidos/<int:pk>/", views.PartidoDetailView.as_view(), name="partido_detail"),
    path("partidos/<int:pk>/editar/", views.PartidoUpdateView.as_view(), name="partido_update"),
    path("partidos/<int:pk>/borrar/", views.PartidoDeleteView.as_view(), name="partido_delete"),
    path("partidos/<int:pk>/marcador/", views.MarcadorUpdateView.as_view(), name="partido_marcador"),

    path("ligas/", views.LigaListView.as_view(), name="liga_list"),
    path("ligas/nueva/", views.LigaCreateView.as_view(), name="liga_create"),
    path("ligas/<int:pk>/", views.LigaDetailView.as_view(), name="liga_detail"),
    path("ligas/<int:pk>/editar/", views.LigaUpdateView.as_view(), name="liga_update"),
    path("ligas/<int:pk>/borrar/", views.LigaDeleteView.as_view(), name="liga_delete"),

    path("equipos/", views.EquipoListView.as_view(), name="equipo_list"),
    path("equipos/nuevo/", views.EquipoCreateView.as_view(), name="equipo_create"),
    path("equipos/<int:pk>/", views.EquipoDetailView.as_view(), name="equipo_detail"),
    path("equipos/<int:pk>/editar/", views.EquipoUpdateView.as_view(), name="equipo_update"),
    path("equipos/<int:pk>/borrar/", views.EquipoDeleteView.as_view(), name="equipo_delete"),

    path("jugadores/", views.JugadorListView.as_view(), name="jugador_list"),
    path("jugadores/nuevo/", views.JugadorCreateView.as_view(), name="jugador_create"),
    path("jugadores/<int:pk>/editar/", views.JugadorUpdateView.as_view(), name="jugador_update"),
    path("jugadores/<int:pk>/borrar/", views.JugadorDeleteView.as_view(), name="jugador_delete"),
]
