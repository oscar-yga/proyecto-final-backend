from .roles import rol_de


def rol(request):
    """Deja el rol del usuario disponible en todos los templates."""
    user = getattr(request, "user", None)
    if user is None or not user.is_authenticated:
        return {"rol_usuario": "visitante", "puede_admin": False, "puede_planillar": False}
    r = rol_de(user)
    return {
        "rol_usuario": r,
        "puede_admin": r == "administrador",
        "puede_planillar": r in ("administrador", "planillero"),
    }
