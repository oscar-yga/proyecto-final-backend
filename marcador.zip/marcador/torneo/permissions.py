from rest_framework.permissions import SAFE_METHODS, BasePermission

from .roles import rol_de

CAMPOS_PLANILLERO = {"goles_local", "goles_visita", "estado"}


class RolPermission(BasePermission):
    """Autorización por rol para toda la API.

    - anónimo: solo lectura (una escritura responde 401 porque la
      autenticación JWT define WWW-Authenticate).
    - lector autenticado (sin grupo): solo lectura; escribir -> 403.
    - planillero: lectura + PATCH de partidos con SOLO goles_local,
      goles_visita y estado; cualquier otra cosa -> 403.
    - administrador: todo.
    """

    message = "Tu rol no tiene permiso para esta acción."

    def has_permission(self, request, view):
        if request.method in SAFE_METHODS:
            return True

        user = request.user
        if not (user and user.is_authenticated):
            return False  # DRF lo convierte en 401 (NotAuthenticated)

        rol = rol_de(user)
        if rol == "administrador":
            return True

        if (
            rol == "planillero"
            and request.method == "PATCH"
            and getattr(view, "permite_planillero", False)
        ):
            datos = request.data
            if not hasattr(datos, "keys"):
                return False
            return set(datos.keys()) <= CAMPOS_PLANILLERO

        return False
