"""Carga datos de ejemplo y usuarios de cada rol para probar el sitio y la API.

Uso:  python manage.py seed
"""
from datetime import timedelta

from django.contrib.auth.models import Group, User
from django.core.management.base import BaseCommand
from django.utils import timezone

from torneo.models import Equipo, Jugador, Liga, Partido
from torneo.roles import GRUPO_ADMINISTRADOR, GRUPO_PLANILLERO

USUARIOS = [
    # username, password, grupo (None = lector)
    ("admin_demo", "Admin-2026!", GRUPO_ADMINISTRADOR),
    ("planillero_demo", "Planilla-2026!", GRUPO_PLANILLERO),
    ("lector_demo", "Lector-2026!", None),
]

EQUIPOS = {
    "Liga Austral": ("Chile", "2026", [
        ("Puerto Montt FC", "Puerto Montt"), ("Osorno United", "Osorno"),
        ("Valdivia Rovers", "Valdivia"), ("Chiloé Sur", "Castro"),
    ]),
    "Copa Patagonia": ("Chile", "2026", [
        ("Coyhaique Norte", "Coyhaique"), ("Punta Arenas FC", "Punta Arenas"),
        ("Aysén Club", "Puerto Aysén"), ("Natales Deportivo", "Puerto Natales"),
    ]),
}
POSICIONES = ["POR", "DEF", "DEF", "MED", "MED", "DEL"]


class Command(BaseCommand):
    help = "Crea grupos, usuarios de prueba y datos de ejemplo (idempotente)."

    def handle(self, *args, **options):
        grupos = {n: Group.objects.get_or_create(name=n)[0]
                  for n in (GRUPO_ADMINISTRADOR, GRUPO_PLANILLERO)}

        for username, password, grupo in USUARIOS:
            user, creado = User.objects.get_or_create(username=username)
            if creado:
                user.set_password(password)
                user.save()
            if grupo:
                user.groups.add(grupos[grupo])

        if Liga.objects.exists():
            self.stdout.write("Ya hay datos: no se crean ligas nuevas.")
        else:
            ahora = timezone.now().replace(minute=0, second=0, microsecond=0)
            for nombre_liga, (pais, temporada, equipos) in EQUIPOS.items():
                liga = Liga.objects.create(nombre=nombre_liga, pais=pais, temporada=temporada)
                objs = []
                for nombre, ciudad in equipos:
                    eq = Equipo.objects.create(nombre=nombre, ciudad=ciudad, liga=liga)
                    objs.append(eq)
                    for i, pos in enumerate(POSICIONES, start=1):
                        Jugador.objects.create(
                            nombre=f"Jugador {i} {nombre.split()[0]}",
                            numero=i, posicion=pos, equipo=eq,
                        )
                a, b, c, d = objs
                Partido.objects.create(liga=liga, local=a, visita=b, fecha=ahora - timedelta(days=7),
                                       estadio="Estadio Municipal", goles_local=2, goles_visita=1,
                                       estado="finalizado")
                Partido.objects.create(liga=liga, local=c, visita=d, fecha=ahora - timedelta(days=7),
                                       estadio="Estadio Costanera", goles_local=1, goles_visita=1,
                                       estado="finalizado")
                Partido.objects.create(liga=liga, local=a, visita=c, fecha=ahora,
                                       estadio="Estadio Municipal", goles_local=1, goles_visita=0,
                                       estado="en_juego")
                Partido.objects.create(liga=liga, local=d, visita=b, fecha=ahora + timedelta(days=3),
                                       estadio="Estadio Austral", estado="programado")

        self.stdout.write(self.style.SUCCESS("Datos de ejemplo listos."))
        self.stdout.write("Usuarios de prueba (cámbiales la clave si los dejas en un servidor):")
        for username, password, grupo in USUARIOS:
            self.stdout.write(f"  {username} / {password}  -> {grupo or 'lector'}")
