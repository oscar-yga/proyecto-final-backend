from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.throttling import ScopedRateThrottle
from rest_framework.views import APIView
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView

from .models import Equipo, Jugador, Liga, Partido
from .roles import rol_de
from .serializers import (
    EquipoSerializer,
    JugadorSerializer,
    LigaSerializer,
    PartidoSerializer,
)
from .tabla import calcular_tabla


def _entero(valor):
    try:
        return int(valor)
    except (TypeError, ValueError):
        return None


def _filtrar_por_id(queryset, request, parametro, campo):
    """Filtra por ?parametro=<id>. Un valor que no es entero -> sin resultados."""
    valor = request.query_params.get(parametro)
    if valor in (None, ""):
        return queryset
    numero = _entero(valor)
    if numero is None:
        return queryset.none()
    return queryset.filter(**{campo: numero})


# ----------------------------------------------------------------- JWT
class LoginView(TokenObtainPairView):
    """POST /api/token/ -> {access, refresh}; 401 si las credenciales fallan."""

    throttle_classes = [ScopedRateThrottle]
    throttle_scope = "login"


class RefreshView(TokenRefreshView):
    """POST /api/token/refresh/ -> {access}."""

    throttle_classes = [ScopedRateThrottle]
    throttle_scope = "login"


class MeView(APIView):
    """GET /api/me/ -> {id, username, rol}; 401 sin token."""

    permission_classes = [IsAuthenticated]

    def get(self, request):
        usuario = request.user
        return Response(
            {"id": usuario.id, "username": usuario.get_username(), "rol": rol_de(usuario)}
        )


# ------------------------------------------------------------ recursos
class LigaViewSet(viewsets.ModelViewSet):
    queryset = Liga.objects.all()
    serializer_class = LigaSerializer

    @action(detail=True, methods=["get"], url_path="tabla")
    def tabla(self, request, pk=None):
        """GET /api/ligas/<id>/tabla/ -> tabla de posiciones (404 si no existe)."""
        liga = self.get_object()
        return Response(calcular_tabla(liga))


class EquipoViewSet(viewsets.ModelViewSet):
    queryset = Equipo.objects.select_related("liga")
    serializer_class = EquipoSerializer

    def get_queryset(self):
        return _filtrar_por_id(super().get_queryset(), self.request, "liga", "liga_id")


class JugadorViewSet(viewsets.ModelViewSet):
    queryset = Jugador.objects.select_related("equipo")
    serializer_class = JugadorSerializer

    def get_queryset(self):
        return _filtrar_por_id(super().get_queryset(), self.request, "equipo", "equipo_id")


class PartidoViewSet(viewsets.ModelViewSet):
    queryset = Partido.objects.select_related("liga", "local", "visita")
    serializer_class = PartidoSerializer
    # El planillero puede hacer PATCH solo en este recurso (ver permissions.py).
    permite_planillero = True

    def get_queryset(self):
        qs = _filtrar_por_id(super().get_queryset(), self.request, "liga", "liga_id")
        estado = self.request.query_params.get("estado")
        if estado:
            validos = {valor for valor, _ in Partido.ESTADOS}
            qs = qs.filter(estado=estado) if estado in validos else qs.none()
        return qs
