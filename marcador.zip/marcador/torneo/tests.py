from django.contrib.auth.models import Group, User
from django.core.cache import cache
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone
from rest_framework.test import APIClient

from .models import Equipo, Liga, Partido

CLAVE = "clave-segura-123"


class DatosBase(TestCase):
    @classmethod
    def setUpTestData(cls):
        g_admin = Group.objects.get_or_create(name="Administrador")[0]
        g_plan = Group.objects.get_or_create(name="Planillero")[0]
        cls.admin = User.objects.create_user("adm", password=CLAVE)
        cls.admin.groups.add(g_admin)
        cls.plan = User.objects.create_user("plan", password=CLAVE)
        cls.plan.groups.add(g_plan)
        cls.lector = User.objects.create_user("lec", password=CLAVE)

        cls.liga = Liga.objects.create(nombre="Liga A", pais="Chile", temporada="2026")
        cls.otra = Liga.objects.create(nombre="Liga B", pais="Chile", temporada="2026")
        cls.a = Equipo.objects.create(nombre="A", ciudad="X", liga=cls.liga)
        cls.b = Equipo.objects.create(nombre="B", ciudad="Y", liga=cls.liga)
        cls.c = Equipo.objects.create(nombre="C", ciudad="Z", liga=cls.liga)
        cls.x = Equipo.objects.create(nombre="X", ciudad="W", liga=cls.otra)
        cls.partido = Partido.objects.create(
            liga=cls.liga, local=cls.a, visita=cls.b, fecha=timezone.now(), estadio="E"
        )

    def setUp(self):
        cache.clear()  # reinicia el throttling entre pruebas


class ApiTests(DatosBase):
    def setUp(self):
        super().setUp()
        self.api = APIClient()

    def entrar(self, username):
        r = self.api.post("/api/token/", {"username": username, "password": CLAVE}, format="json")
        self.assertEqual(r.status_code, 200)
        self.api.credentials(HTTP_AUTHORIZATION="Bearer " + r.data["access"])

    def cuerpo_partido(self, **extra):
        datos = {
            "liga": self.liga.id, "local": self.a.id, "visita": self.c.id,
            "fecha": "2026-10-20T18:00:00-03:00", "estadio": "Nuevo",
            "goles_local": 0, "goles_visita": 0, "estado": "programado",
        }
        datos.update(extra)
        return datos

    # ---- JWT
    def test_token_y_refresh(self):
        r = self.api.post("/api/token/", {"username": "adm", "password": CLAVE}, format="json")
        self.assertEqual(r.status_code, 200)
        self.assertIn("access", r.data)
        self.assertIn("refresh", r.data)
        r2 = self.api.post("/api/token/refresh/", {"refresh": r.data["refresh"]}, format="json")
        self.assertEqual(r2.status_code, 200)
        self.assertIn("access", r2.data)

    def test_token_credenciales_malas_401(self):
        r = self.api.post("/api/token/", {"username": "adm", "password": "mala"}, format="json")
        self.assertEqual(r.status_code, 401)

    def test_me(self):
        self.assertEqual(self.api.get("/api/me/").status_code, 401)
        for usuario, rol in (("adm", "administrador"), ("plan", "planillero"), ("lec", "lector")):
            self.entrar(usuario)
            r = self.api.get("/api/me/")
            self.assertEqual(r.status_code, 200)
            self.assertEqual(r.data["rol"], rol)
            self.assertEqual(r.data["username"], usuario)
            self.assertIn("id", r.data)

    # ---- lectura y contrato
    def test_lectura_anonima_y_campos(self):
        r = self.api.get("/api/partidos/")
        self.assertEqual(r.status_code, 200)
        campos = set(r.data["results"][0].keys())
        self.assertEqual(campos, {
            "id", "liga", "liga_nombre", "local", "local_nombre", "visita", "visita_nombre",
            "fecha", "estadio", "goles_local", "goles_visita", "estado",
        })
        self.assertEqual(set(self.api.get("/api/equipos/").data["results"][0].keys()),
                         {"id", "nombre", "ciudad", "liga", "liga_nombre"})
        self.assertEqual(set(self.api.get("/api/ligas/").data["results"][0].keys()),
                         {"id", "nombre", "pais", "temporada"})

    def test_filtros(self):
        self.assertEqual(self.api.get(f"/api/equipos/?liga={self.otra.id}").data["count"], 1)
        self.assertEqual(self.api.get(f"/api/partidos/?liga={self.otra.id}").data["count"], 0)
        self.assertEqual(self.api.get("/api/partidos/?estado=programado").data["count"], 1)
        self.assertEqual(self.api.get("/api/partidos/?estado=finalizado").data["count"], 0)

    # ---- permisos
    def test_anonimo_no_escribe_401(self):
        self.assertEqual(self.api.post("/api/ligas/", {}, format="json").status_code, 401)
        self.assertEqual(self.api.patch(f"/api/partidos/{self.partido.id}/", {}, format="json").status_code, 401)

    def test_lector_no_escribe_403(self):
        self.entrar("lec")
        self.assertEqual(self.api.post("/api/ligas/", {}, format="json").status_code, 403)

    def test_planillero(self):
        self.entrar("plan")
        url = f"/api/partidos/{self.partido.id}/"
        r = self.api.patch(url, {"goles_local": 2, "goles_visita": 1, "estado": "en_juego"}, format="json")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.data["goles_local"], 2)
        self.assertEqual(r.data["local_nombre"], "A")
        self.assertEqual(self.api.patch(url, {"estadio": "otro"}, format="json").status_code, 403)
        self.assertEqual(self.api.patch(url, {"goles_local": 3, "liga": self.otra.id}, format="json").status_code, 403)
        self.assertEqual(self.api.put(url, self.cuerpo_partido(), format="json").status_code, 403)
        self.assertEqual(self.api.delete(url).status_code, 403)
        self.assertEqual(self.api.post("/api/partidos/", self.cuerpo_partido(), format="json").status_code, 403)
        self.assertEqual(self.api.post("/api/ligas/", {"nombre": "n", "pais": "p", "temporada": "t"}, format="json").status_code, 403)

    def test_admin_crud(self):
        self.entrar("adm")
        r = self.api.post("/api/partidos/", self.cuerpo_partido(), format="json")
        self.assertEqual(r.status_code, 201)
        url = f"/api/partidos/{r.data['id']}/"
        self.assertEqual(self.api.put(url, self.cuerpo_partido(estadio="Otro"), format="json").status_code, 200)
        self.assertEqual(self.api.patch(url, {"goles_local": 4}, format="json").status_code, 200)
        self.assertEqual(self.api.delete(url).status_code, 204)
        self.assertEqual(self.api.get(url).status_code, 404)
        r = self.api.post("/api/ligas/", {"nombre": "Nueva", "pais": "Chile", "temporada": "2027"}, format="json")
        self.assertEqual(r.status_code, 201)

    def test_validaciones_400_y_404(self):
        self.entrar("adm")
        r = self.api.post("/api/partidos/", self.cuerpo_partido(visita=self.a.id), format="json")
        self.assertEqual(r.status_code, 400)
        r = self.api.post("/api/partidos/", self.cuerpo_partido(visita=self.x.id), format="json")
        self.assertEqual(r.status_code, 400)
        r = self.api.post("/api/partidos/", self.cuerpo_partido(estado="inventado"), format="json")
        self.assertEqual(r.status_code, 400)
        self.assertEqual(self.api.get("/api/partidos/99999/").status_code, 404)
        self.assertEqual(self.api.get("/api/ligas/99999/tabla/").status_code, 404)

    # ---- tabla
    def test_tabla(self):
        Partido.objects.create(liga=self.liga, local=self.a, visita=self.b, fecha=timezone.now(),
                               goles_local=2, goles_visita=0, estado="finalizado")
        Partido.objects.create(liga=self.liga, local=self.b, visita=self.c, fecha=timezone.now(),
                               goles_local=1, goles_visita=1, estado="finalizado")
        r = self.api.get(f"/api/ligas/{self.liga.id}/tabla/")
        self.assertEqual(r.status_code, 200)
        filas = {f["equipo"]: f for f in r.data}
        self.assertEqual(r.data[0]["equipo"], "A")
        self.assertEqual(filas["A"]["pts"], 3)
        self.assertEqual(filas["A"]["dg"], 2)
        self.assertEqual(filas["B"]["pts"], 1)
        self.assertEqual(filas["B"]["pj"], 2)
        self.assertEqual(filas["C"]["pts"], 1)
        self.assertEqual(set(filas["A"].keys()),
                         {"equipo_id", "equipo", "pj", "pg", "pe", "pp", "gf", "gc", "dg", "pts"})


class SitioTests(DatosBase):
    def datos_partido(self):
        return {
            "liga": self.liga.id, "local": self.a.id, "visita": self.c.id,
            "fecha": "2026-10-20T18:00", "estadio": "Sitio",
            "goles_local": 0, "goles_visita": 0, "estado": "programado",
        }

    def test_paginas_publicas(self):
        for nombre in ("inicio", "partido_list", "liga_list", "equipo_list", "jugador_list"):
            self.assertEqual(self.client.get(reverse(nombre)).status_code, 200, nombre)
        self.assertEqual(self.client.get(reverse("partido_detail", args=[self.partido.pk])).status_code, 200)
        self.assertEqual(self.client.get(reverse("liga_detail", args=[self.liga.pk])).status_code, 200)

    def test_anonimo_va_al_login(self):
        for url in (reverse("partido_create"),
                    reverse("partido_update", args=[self.partido.pk]),
                    reverse("partido_delete", args=[self.partido.pk]),
                    reverse("partido_marcador", args=[self.partido.pk])):
            r = self.client.get(url)
            self.assertEqual(r.status_code, 302)
            self.assertIn(reverse("login"), r["Location"])

    def test_planillero_403_en_crear_y_borrar_pero_marcador_ok(self):
        self.client.login(username="plan", password=CLAVE)
        self.assertEqual(self.client.get(reverse("partido_create")).status_code, 403)
        self.assertEqual(self.client.post(reverse("partido_delete", args=[self.partido.pk])).status_code, 403)
        self.assertTrue(Partido.objects.filter(pk=self.partido.pk).exists())
        url = reverse("partido_marcador", args=[self.partido.pk])
        self.assertEqual(self.client.get(url).status_code, 200)
        r = self.client.post(url, {"goles_local": 3, "goles_visita": 2, "estado": "finalizado"})
        self.assertEqual(r.status_code, 302)
        self.partido.refresh_from_db()
        self.assertEqual((self.partido.goles_local, self.partido.goles_visita, self.partido.estado),
                         (3, 2, "finalizado"))

    def test_lector_403(self):
        self.client.login(username="lec", password=CLAVE)
        self.assertEqual(self.client.get(reverse("partido_create")).status_code, 403)
        self.assertEqual(self.client.get(reverse("partido_marcador", args=[self.partido.pk])).status_code, 403)

    def test_admin_crud_partido(self):
        self.client.login(username="adm", password=CLAVE)
        r = self.client.post(reverse("partido_create"), self.datos_partido())
        self.assertEqual(r.status_code, 302)
        nuevo = Partido.objects.get(estadio="Sitio")
        r = self.client.post(reverse("partido_update", args=[nuevo.pk]), {**self.datos_partido(), "estadio": "Editado"})
        self.assertEqual(r.status_code, 302)
        nuevo.refresh_from_db()
        self.assertEqual(nuevo.estadio, "Editado")
        r = self.client.post(reverse("partido_delete", args=[nuevo.pk]))
        self.assertEqual(r.status_code, 302)
        self.assertFalse(Partido.objects.filter(pk=nuevo.pk).exists())

    def test_regla_de_negocio_en_formulario(self):
        self.client.login(username="adm", password=CLAVE)
        r = self.client.post(reverse("partido_create"), {**self.datos_partido(), "visita": self.a.id})
        self.assertEqual(r.status_code, 200)  # vuelve al formulario con el error
        self.assertFalse(Partido.objects.filter(estadio="Sitio").exists())

    def test_login_y_navbar_muestra_rol(self):
        r = self.client.post(reverse("login"), {"username": "plan", "password": CLAVE})
        self.assertEqual(r.status_code, 302)
        r = self.client.get(reverse("inicio"))
        self.assertContains(r, "planillero")
        r = self.client.post(reverse("logout"))
        self.assertEqual(r.status_code, 302)
