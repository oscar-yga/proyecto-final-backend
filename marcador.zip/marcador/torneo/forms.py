from django import forms

from .models import Equipo, Jugador, Liga, Partido


class LigaForm(forms.ModelForm):
    class Meta:
        model = Liga
        fields = ["nombre", "pais", "temporada"]


class EquipoForm(forms.ModelForm):
    class Meta:
        model = Equipo
        fields = ["nombre", "ciudad", "liga"]


class JugadorForm(forms.ModelForm):
    class Meta:
        model = Jugador
        fields = ["nombre", "numero", "posicion", "equipo"]


class PartidoForm(forms.ModelForm):
    class Meta:
        model = Partido
        fields = ["liga", "local", "visita", "fecha", "estadio",
                  "goles_local", "goles_visita", "estado"]
        widgets = {
            "fecha": forms.DateTimeInput(
                attrs={"type": "datetime-local"}, format="%Y-%m-%dT%H:%M"
            ),
        }


class MarcadorForm(forms.ModelForm):
    """Lo único que puede editar un planillero."""

    class Meta:
        model = Partido
        fields = ["goles_local", "goles_visita", "estado"]
