import django.db.models.deletion
from django.db import migrations, models


class Migration(migrations.Migration):

    initial = True

    dependencies = []

    operations = [
        migrations.CreateModel(
            name="Liga",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("nombre", models.CharField(max_length=100)),
                ("pais", models.CharField(max_length=60)),
                ("temporada", models.CharField(max_length=20)),
            ],
            options={
                "ordering": ["nombre", "temporada"],
            },
        ),
        migrations.CreateModel(
            name="Equipo",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("nombre", models.CharField(max_length=100)),
                ("ciudad", models.CharField(max_length=80)),
                (
                    "liga",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="equipos",
                        to="torneo.liga",
                    ),
                ),
            ],
            options={
                "ordering": ["nombre"],
            },
        ),
        migrations.CreateModel(
            name="Jugador",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("nombre", models.CharField(max_length=100)),
                ("numero", models.PositiveSmallIntegerField()),
                (
                    "posicion",
                    models.CharField(
                        choices=[
                            ("POR", "Portero"),
                            ("DEF", "Defensa"),
                            ("MED", "Mediocampista"),
                            ("DEL", "Delantero"),
                        ],
                        max_length=3,
                    ),
                ),
                (
                    "equipo",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="jugadores",
                        to="torneo.equipo",
                    ),
                ),
            ],
            options={
                "ordering": ["equipo", "numero"],
            },
        ),
        migrations.CreateModel(
            name="Partido",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("fecha", models.DateTimeField()),
                ("estadio", models.CharField(blank=True, max_length=100)),
                ("goles_local", models.PositiveSmallIntegerField(default=0)),
                ("goles_visita", models.PositiveSmallIntegerField(default=0)),
                (
                    "estado",
                    models.CharField(
                        choices=[
                            ("programado", "Programado"),
                            ("en_juego", "En juego"),
                            ("finalizado", "Finalizado"),
                        ],
                        default="programado",
                        max_length=12,
                    ),
                ),
                (
                    "liga",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="partidos",
                        to="torneo.liga",
                    ),
                ),
                (
                    "local",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="partidos_local",
                        to="torneo.equipo",
                    ),
                ),
                (
                    "visita",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="partidos_visita",
                        to="torneo.equipo",
                    ),
                ),
            ],
            options={
                "ordering": ["fecha", "id"],
            },
        ),
    ]
