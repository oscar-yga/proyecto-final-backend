from .models import Partido


def calcular_tabla(liga):
    """Tabla de posiciones con los partidos FINALIZADOS de la liga.

    3 puntos por victoria, 1 por empate. Orden: pts, diferencia de gol,
    goles a favor (y nombre como desempate estable).
    """
    filas = {
        e.id: {
            "equipo_id": e.id,
            "equipo": e.nombre,
            "pj": 0, "pg": 0, "pe": 0, "pp": 0,
            "gf": 0, "gc": 0, "dg": 0, "pts": 0,
        }
        for e in liga.equipos.all()
    }

    for p in liga.partidos.filter(estado=Partido.FINALIZADO):
        local = filas.get(p.local_id)
        visita = filas.get(p.visita_id)
        if local is None or visita is None:
            continue
        local["pj"] += 1
        visita["pj"] += 1
        local["gf"] += p.goles_local
        local["gc"] += p.goles_visita
        visita["gf"] += p.goles_visita
        visita["gc"] += p.goles_local
        if p.goles_local > p.goles_visita:
            local["pg"] += 1
            visita["pp"] += 1
            local["pts"] += 3
        elif p.goles_local < p.goles_visita:
            visita["pg"] += 1
            local["pp"] += 1
            visita["pts"] += 3
        else:
            local["pe"] += 1
            visita["pe"] += 1
            local["pts"] += 1
            visita["pts"] += 1

    for f in filas.values():
        f["dg"] = f["gf"] - f["gc"]

    return sorted(
        filas.values(),
        key=lambda f: (-f["pts"], -f["dg"], -f["gf"], f["equipo"].lower()),
    )
