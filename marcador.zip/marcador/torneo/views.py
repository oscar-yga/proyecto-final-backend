from django.contrib.auth.views import LogoutView
from django.contrib.messages.views import SuccessMessageMixin
from django.urls import reverse_lazy
from django.views.generic import (
    CreateView,
    DeleteView,
    DetailView,
    ListView,
    TemplateView,
    UpdateView,
)

from .forms import EquipoForm, JugadorForm, LigaForm, MarcadorForm, PartidoForm
from .models import Equipo, Jugador, Liga, Partido
from .roles import AdministradorRequiredMixin, PlanilleroRequiredMixin
from .tabla import calcular_tabla


class SalirView(LogoutView):
    """Cierra sesión por POST (formulario con csrf_token en la navbar).
    También acepta GET para que un enlace simple a /accounts/logout/ funcione."""

    http_method_names = ["get", "post", "head", "options"]

    def get(self, request, *args, **kwargs):
        return self.post(request, *args, **kwargs)


# ------------------------------------------------------------------ inicio
class InicioView(TemplateView):
    template_name = "torneo/inicio.html"

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        base = Partido.objects.select_related("liga", "local", "visita")
        ctx["en_juego"] = base.filter(estado=Partido.EN_JUEGO)
        ctx["proximos"] = base.filter(estado=Partido.PROGRAMADO)[:6]
        ctx["recientes"] = base.filter(estado=Partido.FINALIZADO).order_by("-fecha")[:6]
        ctx["ligas"] = Liga.objects.all()
        return ctx


# ----------------------------------------------------------------- partidos
class PartidoListView(ListView):
    model = Partido
    template_name = "torneo/partido_list.html"
    context_object_name = "partidos"

    def get_queryset(self):
        qs = Partido.objects.select_related("liga", "local", "visita")
        liga = self.request.GET.get("liga", "")
        estado = self.request.GET.get("estado", "")
        if liga.isdigit():
            qs = qs.filter(liga_id=int(liga))
        if estado in {valor for valor, _ in Partido.ESTADOS}:
            qs = qs.filter(estado=estado)
        return qs

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["ligas"] = Liga.objects.all()
        ctx["estados"] = Partido.ESTADOS
        ctx["liga_sel"] = self.request.GET.get("liga", "")
        ctx["estado_sel"] = self.request.GET.get("estado", "")
        return ctx


class PartidoDetailView(DetailView):
    model = Partido
    template_name = "torneo/partido_detail.html"
    context_object_name = "partido"

    def get_queryset(self):
        return Partido.objects.select_related("liga", "local", "visita")


class PartidoCreateView(AdministradorRequiredMixin, SuccessMessageMixin, CreateView):
    model = Partido
    form_class = PartidoForm
    template_name = "torneo/form.html"
    success_message = "Partido creado."
    extra_context = {"titulo": "Nuevo partido"}


class PartidoUpdateView(AdministradorRequiredMixin, SuccessMessageMixin, UpdateView):
    model = Partido
    form_class = PartidoForm
    template_name = "torneo/form.html"
    success_message = "Partido actualizado."
    extra_context = {"titulo": "Editar partido"}


class PartidoDeleteView(AdministradorRequiredMixin, SuccessMessageMixin, DeleteView):
    model = Partido
    template_name = "torneo/confirmar_borrar.html"
    success_url = reverse_lazy("partido_list")
    success_message = "Partido eliminado."


class MarcadorUpdateView(PlanilleroRequiredMixin, SuccessMessageMixin, UpdateView):
    """/partidos/<id>/marcador/: planillero y administrador."""

    model = Partido
    form_class = MarcadorForm
    template_name = "torneo/marcador_form.html"
    success_message = "Marcador actualizado."


# -------------------------------------------------------------------- ligas
class LigaListView(ListView):
    model = Liga
    template_name = "torneo/liga_list.html"
    context_object_name = "ligas"


class LigaDetailView(DetailView):
    model = Liga
    template_name = "torneo/liga_detail.html"
    context_object_name = "liga"

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["tabla"] = calcular_tabla(self.object)
        ctx["equipos"] = self.object.equipos.all()
        ctx["partidos"] = self.object.partidos.select_related("local", "visita", "liga")
        return ctx


class LigaCreateView(AdministradorRequiredMixin, SuccessMessageMixin, CreateView):
    model = Liga
    form_class = LigaForm
    template_name = "torneo/form.html"
    success_message = "Liga creada."
    extra_context = {"titulo": "Nueva liga"}


class LigaUpdateView(AdministradorRequiredMixin, SuccessMessageMixin, UpdateView):
    model = Liga
    form_class = LigaForm
    template_name = "torneo/form.html"
    success_message = "Liga actualizada."
    extra_context = {"titulo": "Editar liga"}


class LigaDeleteView(AdministradorRequiredMixin, SuccessMessageMixin, DeleteView):
    model = Liga
    template_name = "torneo/confirmar_borrar.html"
    success_url = reverse_lazy("liga_list")
    success_message = "Liga eliminada."


# ------------------------------------------------------------------ equipos
class EquipoListView(ListView):
    model = Equipo
    template_name = "torneo/equipo_list.html"
    context_object_name = "equipos"

    def get_queryset(self):
        return Equipo.objects.select_related("liga")


class EquipoDetailView(DetailView):
    model = Equipo
    template_name = "torneo/equipo_detail.html"
    context_object_name = "equipo"

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["jugadores"] = self.object.jugadores.all()
        return ctx


class EquipoCreateView(AdministradorRequiredMixin, SuccessMessageMixin, CreateView):
    model = Equipo
    form_class = EquipoForm
    template_name = "torneo/form.html"
    success_message = "Equipo creado."
    extra_context = {"titulo": "Nuevo equipo"}


class EquipoUpdateView(AdministradorRequiredMixin, SuccessMessageMixin, UpdateView):
    model = Equipo
    form_class = EquipoForm
    template_name = "torneo/form.html"
    success_message = "Equipo actualizado."
    extra_context = {"titulo": "Editar equipo"}


class EquipoDeleteView(AdministradorRequiredMixin, SuccessMessageMixin, DeleteView):
    model = Equipo
    template_name = "torneo/confirmar_borrar.html"
    success_url = reverse_lazy("equipo_list")
    success_message = "Equipo eliminado."


# ----------------------------------------------------------------- jugadores
class JugadorListView(ListView):
    model = Jugador
    template_name = "torneo/jugador_list.html"
    context_object_name = "jugadores"

    def get_queryset(self):
        return Jugador.objects.select_related("equipo")


class JugadorCreateView(AdministradorRequiredMixin, SuccessMessageMixin, CreateView):
    model = Jugador
    form_class = JugadorForm
    template_name = "torneo/form.html"
    success_message = "Jugador creado."
    extra_context = {"titulo": "Nuevo jugador"}


class JugadorUpdateView(AdministradorRequiredMixin, SuccessMessageMixin, UpdateView):
    model = Jugador
    form_class = JugadorForm
    template_name = "torneo/form.html"
    success_message = "Jugador actualizado."
    extra_context = {"titulo": "Editar jugador"}


class JugadorDeleteView(AdministradorRequiredMixin, SuccessMessageMixin, DeleteView):
    model = Jugador
    template_name = "torneo/confirmar_borrar.html"
    success_url = reverse_lazy("jugador_list")
    success_message = "Jugador eliminado."
