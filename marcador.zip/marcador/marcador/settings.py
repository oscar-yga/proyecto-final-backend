"""Configuración del proyecto Marcador en Vivo (Django + DRF + JWT)."""
import os
from datetime import timedelta
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent


def _bool(valor, defecto=False):
    """Convierte una variable de entorno de texto a booleano."""
    if valor is None:
        return defecto
    return str(valor).strip().lower() in ("1", "true", "yes", "si", "sí", "on")


def _lista(valor, defecto):
    """Convierte 'a,b,c' en ['a', 'b', 'c']."""
    texto = valor if valor is not None else defecto
    return [x.strip() for x in texto.split(",") if x.strip()]


# --------------------------------------------------------------------------
# Seguridad (ver SEGURIDAD.md)
# --------------------------------------------------------------------------
# El valor por defecto SOLO sirve para desarrollo: en producción se define
# DJANGO_SECRET_KEY en el entorno.
SECRET_KEY = os.environ.get(
    "DJANGO_SECRET_KEY",
    "dev-solo-desarrollo-cambiar-en-produccion-3f9a1c7e5b2d4a60",
)
DEBUG = _bool(os.environ.get("DJANGO_DEBUG"), True)
ALLOWED_HOSTS = _lista(
    os.environ.get("DJANGO_ALLOWED_HOSTS"), "127.0.0.1,localhost,testserver"
)

# CORS restringido al origen del front externo (Live Server). Nunca se usa
# CORS_ALLOW_ALL_ORIGINS.
CORS_ALLOWED_ORIGINS = _lista(
    os.environ.get("CORS_ALLOWED_ORIGINS"),
    "http://127.0.0.1:5500,http://localhost:5500",
)
CORS_ALLOW_CREDENTIALS = False

X_FRAME_OPTIONS = "DENY"
SECURE_CONTENT_TYPE_NOSNIFF = True
if not DEBUG:
    SESSION_COOKIE_SECURE = True
    CSRF_COOKIE_SECURE = True

# --------------------------------------------------------------------------
# Aplicaciones y middleware
# --------------------------------------------------------------------------
INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "rest_framework",
    "corsheaders",
    "torneo",
]

MIDDLEWARE = [
    "corsheaders.middleware.CorsMiddleware",  # lo más arriba posible
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

ROOT_URLCONF = "marcador.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
                "torneo.context_processors.rol",
            ],
        },
    },
]

WSGI_APPLICATION = "marcador.wsgi.application"

DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.sqlite3",
        "NAME": BASE_DIR / "db.sqlite3",
    }
}

AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator"},
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator"},
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},
]

LANGUAGE_CODE = "es-cl"
TIME_ZONE = "America/Santiago"
USE_I18N = True
USE_TZ = True

STATIC_URL = "static/"
DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

# Sesión del sitio HTML
LOGIN_URL = "login"
LOGIN_REDIRECT_URL = "inicio"
LOGOUT_REDIRECT_URL = "inicio"

# --------------------------------------------------------------------------
# Django REST Framework
# --------------------------------------------------------------------------
REST_FRAMEWORK = {
    # Solo JWT: sin SessionAuthentication, así una petición sin token recibe
    # 401 (con cabecera WWW-Authenticate) y no 403.
    "DEFAULT_AUTHENTICATION_CLASSES": [
        "rest_framework_simplejwt.authentication.JWTAuthentication",
    ],
    # Permiso propio por rol (torneo/permissions.py).
    "DEFAULT_PERMISSION_CLASSES": ["torneo.permissions.RolPermission"],
    "DEFAULT_RENDERER_CLASSES": ["rest_framework.renderers.JSONRenderer"],
    "DEFAULT_PAGINATION_CLASS": "rest_framework.pagination.PageNumberPagination",
    "PAGE_SIZE": 100,
    # Throttling (límite de peticiones).
    "DEFAULT_THROTTLE_CLASSES": [
        "rest_framework.throttling.AnonRateThrottle",
        "rest_framework.throttling.UserRateThrottle",
    ],
    "DEFAULT_THROTTLE_RATES": {
        "anon": "300/min",
        "user": "600/min",
        "login": "100/min",  # /api/token/ y /api/token/refresh/
    },
}

# Access token de vida corta: máximo 60 minutos (por defecto 30).
_minutos_access = min(int(os.environ.get("JWT_ACCESS_MINUTES", "30")), 60)
SIMPLE_JWT = {
    "ACCESS_TOKEN_LIFETIME": timedelta(minutes=_minutos_access),
    "REFRESH_TOKEN_LIFETIME": timedelta(days=1),
    "ROTATE_REFRESH_TOKENS": False,
    "AUTH_HEADER_TYPES": ("Bearer",),
}
