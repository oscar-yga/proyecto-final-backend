from django.contrib import admin
from django.contrib.auth.views import LoginView
from django.urls import include, path

from torneo.views import SalirView

urlpatterns = [
    path("admin/", admin.site.urls),
    path("accounts/login/", LoginView.as_view(redirect_authenticated_user=True), name="login"),
    path("accounts/logout/", SalirView.as_view(), name="logout"),
    path("api/", include("torneo.api_urls")),
    path("", include("torneo.urls")),
]
