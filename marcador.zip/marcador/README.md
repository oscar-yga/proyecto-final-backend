# Marcador en Vivo — Evaluación 3

Proyecto Django con sitio HTML por roles y API REST (DRF + JWT) para el front externo del profesor.

## Puesta en marcha
```bash
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python manage.py migrate
python manage.py seed            # opcional: datos de ejemplo y usuarios de prueba
python manage.py runserver       # http://127.0.0.1:8000
```
Front externo: abrir `front_externo/index.html` con Live Server (http://127.0.0.1:5500).

## Usuarios de prueba (`seed`)
| Usuario | Clave | Rol |
|---------|-------|-----|
| admin_demo | Admin-2026! | Administrador |
| planillero_demo | Planilla-2026! | Planillero |
| lector_demo | Lector-2026! | lector |

Para entrar al Django Admin: `python manage.py createsuperuser`.

## Pruebas
```bash
python manage.py test
```

## Dónde está cada cosa
- Sitio HTML: `torneo/views.py`, `torneo/urls.py`, `torneo/templates/`
- Roles: `torneo/roles.py` (grupos "Administrador" y "Planillero", creados por la migración 0002)
- API: `torneo/serializers.py`, `torneo/api_views.py`, `torneo/api_urls.py`, `torneo/permissions.py`
- Tabla de posiciones: `torneo/tabla.py`
- Seguridad: `SEGURIDAD.md` y `marcador/settings.py`
